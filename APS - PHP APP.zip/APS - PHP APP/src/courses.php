<?php
include("includes/header.php");
include("includes/database.php");


$page = isset($_GET['page']) ? intval($_GET['page']) : 1;

// Calculate the LIMIT and OFFSET values based on the current page number
$per_page = 9;
$offset = ($page - 1) * $per_page;


$sqlString = "SELECT course.qualificationName, course.qualification, course.duration, course.withMathsScore, course.withMathsLitScore, course.minMaths, course.minMathsLit, qualificationType.qualificationTypeName, university.universityAbriviationName, faculty.facultyName
FROM course AS course
INNER JOIN university AS university ON course.universityID = university.universityID
INNER JOIN qualificationType AS qualificationType ON course.qualificationTypeID = qualificationType.qualificationTypeID
INNER JOIN faculty AS faculty ON course.facultyID = faculty.facultyID
WHERE 1 = 1";

//DECLARING VARIABLE

if (isset($_POST['findCourse'])) {

    $homeLanguage = $_POST['homeLanguage'];
    $homeLanguageScore = $_POST['homeLanguageScore'];
    $mathsOption = $_POST['mathsOption'];
    $mathsOptionScore = $_POST['mathsOptionScore'];
    $apsScore = $_POST['apsScore'];

    if ($homeLanguageScore > 49) {
        $sqlString = $sqlString . " AND (withMathsScore <= $apsScore OR withMathsLitScore <= $apsScore)";
        $sqlString = $sqlString . " AND (minMaths <= $mathsOptionScore OR (minMathsLit <= $mathsOptionScore AND minMathsLit > 0))";
        
    } else {
        echo "You do not have enough enough aps";
    }
}



$sqlString = $sqlString . " LIMIT $per_page OFFSET $offset";
$records = mysqli_query($conn, $sqlString);


?>

<section class="container mt-5 mb-md-2 mb-lg-4 mb-xl-5">
    <nav class="pt-4 mt-lg-3" aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item">
                <a href="landing-online-courses.html"><i class="bx bx-home-alt fs-lg me-1"></i>Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Courses</li>
        </ol>
    </nav>

    <div class="d-lg-flex align-items-center justify-content-between py-4 mt-lg-2">
        <h1 class="me-3">Courses</h1>
        <div class="d-md-flex mb-3">
            <select class="form-select me-md-4 mb-2 mb-md-0" style="min-width: 240px;">
                <option value="All">All categories</option>
                <option value="Web Development">Web Development</option>
                <option value="Mobile Development">Mobile Development</option>
                <option value="Programming">Programming</option>
                <option value="Game Development">Game Development</option>
                <option value="Software Testing">Software Testing</option>
                <option value="Software Engineering">Software Engineering</option>
                <option value="Network &amp; Security">Network &amp; Security</option>
            </select>
            <select class="form-select me-md-4 mb-2 mb-md-0" style="min-width: 240px;">
                <option value="All">All Faculties</option>
                <option value="Web Development">Web Development</option>
                <option value="Mobile Development">Mobile Development</option>
                <option value="Programming">Programming</option>
                <option value="Game Development">Game Development</option>
                <option value="Software Testing">Software Testing</option>
                <option value="Software Engineering">Software Engineering</option>
                <option value="Network &amp; Security">Network &amp; Security</option>
            </select>
            <div class="position-relative" style="min-width: 300px;">
                <input type="text" class="form-control pe-5" placeholder="Search courses">
                <i class="bx bx-search text-nav fs-lg position-absolute top-50 end-0 translate-middle-y me-3"></i>
            </div>
        </div>
    </div>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 gx-3 gx-md-4 mt-n2 mt-sm-0">
        <?php
        while ($data = mysqli_fetch_array($records)) {

        ?>

            <div class="col pb-1 pb-lg-3 mb-4">
                <article class="card h-100 card-hover border-0 shadow-sm">
                    <div class="card-body pb-4">
                        <h5 class="h5 mb-0">
                            <a href="#"><?php echo $data['qualificationName']; ?></a>
                        </h5>
                        <p class="subHeading muted mb-4"><?php echo $data['qualification']; ?></p>
                        <p>Sapien, nulla placerat in at. Vitae tincidunt quam ornare massa porttitor. Neque a vitae feugiat in sit habitant integer. Cursus et at pulvinar sed neque vitae. Aliquam vitae hac phasellus.</p>
                        <div class="table-responsive">
                            <table class="table table-borderless" style="padding: 0; margin: 0;">
                                <tbody class="tableStyling">
                                    <tr style="border-style: none;">
                                        <td class="px-0">
                                            <p class="fs-sm mb-2"> Offerd:
                                                <span class="h6">
                                                    <a href="#"><?php echo $data['universityAbriviationName']; ?></a>
                                                </span>
                                            </p>
                                        </td>
                                        <td class="px-0">
                                            <p class="fs-sm mb-2">
                                                Score:
                                                <span class="h6"><?php echo $data['withMathsLitScore']; ?></span>
                                            </p>
                                        </td>
                                        <td class="px-0">
                                            <p class="fs-sm mb-2">
                                                Duration:
                                                <span class="h6"><?php echo $data['duration']; ?> Year</span>
                                            </p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center fs-sm text-muted py-4">
                        <div class="d-flex align-items-center me-4">
                            <a href="#" class="btn btn-sm btn-primary" style="margin-right: 5px;">Go somewhere</a>
                            <a href="#" class="btn btn-sm btn-primary">Go somewhere</a>
                        </div>
                    </div>
                </article>
            </div>

        <?php
        }

        ?>

    </div>

    <!--add the php for pagination here-->
    <?php

    $records = mysqli_query($conn, "SELECT course.qualificationName, course.qualification, course.duration, course.withMathsScore, course.withMathsLitScore, course.minMaths, course.minMathsLit, qualificationType.qualificationTypeName, university.universityAbriviationName, faculty.facultyName FROM course AS course
            INNER JOIN university AS university ON course.universityID = university.universityID
            INNER JOIN qualificationType AS qualificationType ON course.qualificationTypeID = qualificationType.qualificationTypeID
            INNER JOIN faculty AS faculty ON course.facultyID = faculty.facultyID");

    $total_records = mysqli_num_rows($records);
    //echo $total_records;
    $total_pages = ceil($total_records / $per_page);

    echo '<nav aria-label="Page navigation example" class="nav justify-content-center">';
    echo '<ul class="pagination">';
    echo '<li class="page-item">';
    echo '<a href="#" class="page-link">';
    echo '<i class="bx bx-chevron-left mx-n1"></i>';
    echo '</a>';
    echo '</li>';
    for ($i = 1; $i <= $total_pages; $i++) {
        //echo "<a href='courses.php?page=" . $i . "'>" . $i . "</a>";
        echo '<li class="page-item' . ($i == $page ? ' active' : '') . '">';
        echo '<a href="?page=' . $i . '" class="page-link">' . $i . '</a>';
        echo '</li>';
    }
    echo '<li class="page-item">';
    echo '<a href="#" class="page-link">';
    echo '<i class="bx bx-chevron-right mx-n1"></i>';
    echo '</a>';
    echo '</li>';
    echo '</ul>';
    echo '</nav>';
    ?>
    <!--add the php for pagination here-->

</section>

<?php
include("includes/footer.php");
?>