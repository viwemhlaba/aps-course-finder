<?php
session_start();
include("includes/header.php");
include("includes/database.php");

/* $x = isset($_GET['x']) ? intval($_GET['x']) : 5; // Add this line here
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;


//delcaring

// Calculate the LIMIT and OFFSET values based on the current page number
$per_page = 9;
$offset = ($page - 1) * $per_page; */

$query = "SELECT course.qualificationName, course.qualification, course.duration, qualificationType.qualificationTypeName, university.universityAbriviationName, faculty.facultyName 
FROM course 
INNER JOIN university ON course.universityID = university.universityID 
INNER JOIN qualificationType ON course.qualificationTypeID = qualificationType.qualificationTypeID 
INNER JOIN faculty ON course.facultyID = faculty.facultyID 
WHERE 1 = 1";

/* $x = 5; */

if (isset($_GET['findCourse'])) {

    /* $x = 5; */
    $homeLanguage = mysqli_real_escape_string($conn, $_GET['homeLanguage']);
    $homeLanguageScore = intval($_GET['homeLanguageScore']);
    $mathsOption = mysqli_real_escape_string($conn, $_GET['mathsOption']);
    $mathsOptionScore = intval($_GET['mathsOptionScore']);
    $apsScore = intval($_GET['apsScore']);

    if ($apsScore >= 290 && $homeLanguageScore >= 50) {
        /* if ($mathsOption === "Mathslit" && $mathsOptionScore >= 35) {
            $query = "SELECT *, university.universityAbriviationName
            FROM course 
            INNER JOIN university ON course.universityID = university.universityID 
            WHERE withMathsLitScore <= $apsScore AND minMathsLit > 0 and minMathsLit <= $mathsOptionScore
            LIMIT $per_page OFFSET $offset";
            $x = $x + 1;
        } else if ($mathsOption === "Maths" && $mathsOptionScore >= 30) {
            $query = "SELECT *, university.universityAbriviationName
            FROM course 
            INNER JOIN university ON course.universityID = university.universityID 
            WHERE withMathsScore <= $apsScore AND minMaths > 0 and minMaths <= $mathsOptionScore
            LIMIT $per_page OFFSET $offset";
            $x = $x - 1;
        } */

        if ($x >= 5) {
            $query = "SELECT *, university.universityAbriviationName
            FROM course 
            INNER JOIN university ON course.universityID = university.universityID 
            WHERE withMathsLitScore <= $apsScore AND minMathsLit > 0 and minMathsLit <= $mathsOptionScore
            LIMIT $per_page OFFSET $offset";
            $x = $x + 1;
        } else {
            $query = "SELECT *, university.universityAbriviationName
            FROM course 
            INNER JOIN university ON course.universityID = university.universityID 
            WHERE withMathsScore <= $apsScore AND minMaths > 0 and minMaths <= $mathsOptionScore
            LIMIT $per_page OFFSET $offset";
            $x = $x - 1;
        }
    }
}

$results = mysqli_query($conn, $query);

?>

<section class="container mt-5 mb-md-2 mb-lg-4 mb-xl-5">
    <nav class="pt-4 mt-lg-3" aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item">
                <a href="landing-online-courses.html"><i class="bx bx-home-alt fs-lg me-1"></i>Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Courses</li>
        </ol>
    </nav>
    <div class="d-lg-flex align-items-center justify-content-between py-4 mt-lg-2">
        <h1 class="me-3">Courses</h1>
        <div class="d-md-flex mb-3">
            <select class="form-select me-md-4 mb-2 mb-md-0" style="min-width: 240px;">
                <option value="All">All categories</option>
                <option value="Web Development">Web Development</option>
                <option value="Mobile Development">Mobile Development</option>
                <option value="Programming">Programming</option>
                <option value="Game Development">Game Development</option>
                <option value="Software Testing">Software Testing</option>
                <option value="Software Engineering">Software Engineering</option>
                <option value="Network &amp; Security">Network &amp; Security</option>
            </select>
            <select class="form-select me-md-4 mb-2 mb-md-0" style="min-width: 240px;">
                <option value="All">All Faculties</option>
                <option value="Web Development">Web Development</option>
                <option value="Mobile Development">Mobile Development</option>
                <option value="Programming">Programming</option>
                <option value="Game Development">Game Development</option>
                <option value="Software Testing">Software Testing</option>
                <option value="Software Engineering">Software Engineering</option>
                <option value="Network &amp; Security">Network &amp; Security</option>
            </select>
            <div class="position-relative" style="min-width: 300px;">
                <input type="text" class="form-control pe-5" placeholder="Search courses">
                <i class="bx bx-search text-nav fs-lg position-absolute top-50 end-0 translate-middle-y me-3"></i>
            </div>
        </div>
    </div>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 gx-3 gx-md-4 mt-n2 mt-sm-0">
        <?php
        while ($data = mysqli_fetch_array($results)) {
        ?>

            <div class="col pb-1 pb-lg-3 mb-4">
                <article class="card h-100 card-hover border-0 shadow-sm">
                    <div class="card-body pb-4">
                        <h5 class="h5 mb-0">
                            <a href="#"><?php echo $data['qualificationName']; ?></a>
                        </h5>
                        <p class="subHeading muted mb-4"><?php echo $data['qualification']; ?></p>
                        <p>Sapien, nulla placerat in at. Vitae tincidunt quam ornare massa porttitor. Neque a vitae feugiat
                            in sit habitant integer. Cursus et at pulvinar sed neque vitae. Aliquam vitae hac phasellus.</p>
                        <div class="table-responsive">
                            <table class="table table-borderless" style="padding: 0; margin: 0;">
                                <tbody class="tableStyling">
                                    <tr style="border-style: none;">
                                        <td class="px-0">
                                            <p class="fs-sm mb-2"> Offerd:
                                                <span class="h6">
                                                    <a href="#"><?php echo $data['universityAbriviationName']; ?></a>
                                                </span>
                                            </p>
                                        </td>
                                        <td class="px-0">
                                            <p class="fs-sm mb-2">
                                                Score:
                                                <?php
                                                if ($x >= 5) {
                                                    echo '<span class="h6">' . $data['withMathsScore'] . '</span>';
                                                } else {
                                                    echo '<span class="h6">' . $data['withMathsLitScore'] . '</span>';
                                                }

                                                ?>
                                            </p>
                                        </td>
                                        <td class="px-0">
                                            <p class="fs-sm mb-2">
                                                Duration:
                                                <span class="h6"><?php echo $data['duration']; ?> Year</span>
                                            </p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer d-flex align-items-center fs-sm text-muted py-4">
                        <div class="d-flex align-items-center me-4">
                            <a href="#" class="btn btn-sm btn-primary" style="margin-right: 5px;">Go somewhere</a>
                            <a href="#" class="btn btn-sm btn-primary">Go somewhere</a>
                        </div>
                    </div>
                </article>
            </div>

        <?php
        }

        ?>

    </div>


</section>

<?php
include("includes/footer.php");
?>