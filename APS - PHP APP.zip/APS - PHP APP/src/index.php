<?php

include("./includes/database.php");

$alertMessage = "";

if (isset($_GET['index']) && $_GET['index'] == 'empty') {
    $alertMessage = '<div class="alert alert-danger d-flex align-items-center" role="alert">APS low!</div>';
}

include("includes/header.php");
?>
<!--hero starts-->
<section class="overflow-hidden">
    <div class="container pt-3 pt-sm-4">
        <div class="row pt-md-2 pt-lg-5">
            <div class="col-md-6 d-flex flex-column mt-md-4 pt-5 pb-3 pr-3 pb-sm-4 py-md-5">
                <h1 class="display-5 text-center text-md-start mb-4">We will match your Applicant Score with over 100+
                    Courses
                </h1>
                <p class="fs-lg text-center text-md-start pb-2 pb-md-3 mb-4 mb-lg-5">Explore hundreds of courses
                    that match your AS score and choose <br>the best fit for your interests, skills, and career
                    goals. </p>
                <div class="d-flex flex-column flex-sm-row justify-content-center justify-content-md-start">
                    <a href="pages\university.php" class="btn btn-primary btn-lg px-3 py-2 me-sm-3 me-lg-4 mb-3">
                        Find Universities
                    </a>
                    <a href="pages\contact.php" class="btn btn-light btn-lg px-3 py-2 me-sm-3 me-lg-4 mb-3">
                        Contact Us
                    </a>
                </div>

            </div>
            <div class="col-md-6 align-self-center">

                <div class="card border-light shadow-lg p-sm3 p-md-5 mb-5">
                    <div class="card-body position-relative zindex-2">
                        <h2 class="card-title pb-3 mb-4">Find Your Ideal Course</h2>
                        <form class="row g-4 needs-validation" novalidate="" action="discoverCourses.php" method="GET">
                            <div class="col-12">
                                <?php if (isset($alertMessage)) { ?>
                                    <div class="col-12">
                                        <?php echo $alertMessage ?>
                                    </div>
                                <?php } ?>
                                <div class="input-group d-block d-sm-flex input-group-lg me-3">

                                    <select class="form-select w-50 text-dark" id="homeLanguage" name="homeLanguage" required>
                                        <option value="">First Language</option>
                                        <option value="IsiXhosa">IsiXhosa</option>
                                        <option value="Afrikaans">Afrikaans</option>
                                        <option value="English">English</option>
                                        <option value="IsiNdebele">IsiNdebele</option>
                                        <option value="IsiZulu">IsiZulu</option>
                                        <option value="Sepedi">Sepedi</option>
                                        <option value="Sesotho">Sesotho</option>
                                        <option value="Setswana">Setswana</option>
                                        <option value="SiSwati">SiSwati</option>
                                        <option value="Tshivenda">Tshivenda</option>
                                        <option value="Xitsonga">Xitsonga</option>
                                    </select>

                                    <input type="text" class="form-control w-50" id="homeLanguageScore" placeholder="What Percentage you got?" name="homeLanguageScore" required="" data-bs-toggle="tooltip" data-bs-placement="right" title="If you got level 4: 58%, then your score is 58">
                                    <div class="feedBclass invalid-feedback">Please enter your score</div>
                                </div>


                            </div>
                            <div class="col-12">
                                <div class="input-group d-block d-sm-flex input-group-lg me-3">
                                    <select class="form-select w-50 text-dark" name="mathsOption" id="mathsOption" required>
                                        <option value="" selected="" disabled="">Choose maths option</option>
                                        <option value="Maths">Mathematics</option>
                                        <option value="Mathslit">Mathematics Literacy</option>

                                    </select>
                                    <input type="text" class="form-control w-50" name="mathsOptionScore" id="mathsOptionScore" placeholder="What Percentage you got?" required="" data-bs-toggle="tooltip" data-bs-placement="right" title="If you got level 4: 58%, then your score is 58">
                                    <div class="feedBclass invalid-feedback">Please enter your score</div>

                                </div>

                            </div>
                            <div class="col-12">
                                <div class="input-group d-block d-sm-flex input-group-lg me-3">
                                    <input type="text" class="form-control w-50" placeholder="Total Matric Score" required="" disabled>

                                    <input type="text" class="form-control w-50" name="apsScore" id="apsScore" placeholder="What is your total score?" required="" data-bs-toggle="tooltip" data-bs-placement="right" title="Add all 6 subjects, without includiding LO">
                                    <div class="feedBclass invalid-feedback">Please enter your score</div>

                                </div>

                            </div>
                            <div class="calLink col-12">
                                <p>Not sure how to add your score, use our <a href="calculator.html">APS calculator</a>
                                </p>
                            </div>

                            <div class="btnLink col-12 pt-2 pt-sm-3">
                                <button type="submit" name="findCourse" id="discoverCourse" class="btn btn-lg btn-primary w-100 w-sm-auto">Find Your Ideal Course</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>

        </div>
    </div>

</section>
<!--hero ends-->

<!--why us section-->
<section class="whyussection container pt-5 pt-xl-3 pb-5">
    <h2 class="h1 text-center pb-3 pb-md-0 mb-md-5">Why Use Our Platform</h2>
    <div class="swiper swiper-nav-onhover mt-n3 mx-n2" data-swiper-options='{
                "slidesPerView": 1,
                "spaceBetween": 8,
                "pagination": {
                  "el": ".swiper-pagination",
                  "clickable": true
                },
                "breakpoints": {
                  "600": {
                    "slidesPerView": 2
                  },
                  "1000": {
                    "slidesPerView": 3
                  }
                }
              }'>
        <div class="swiper-wrapper">

            <!-- Item -->
            <div class="swiper-slide h-auto py-3">
                <div class="card card-hover h-100 mx-2">
                    <div class="card-body">
                        <div class="d-table position-relative p-3 mb-4">
                            <img src="assets/img/landing/online-courses/icons/01.svg" class="position-relative zindex-2" width="32" alt="Icon">
                            <span class="bg-primary position-absolute top-0 start-0 w-100 h-100 rounded-circle opacity-8"></span>
                        </div>
                        <h3 class="h5 pb-1 mb-2">Personalized recommendations</h3>
                        <p class="mb-0">We provide personalized course recommendations based on your AS score,
                            so you can be sure that you're exploring courses that match your qualifications and
                            interests.</p>
                    </div>
                </div>
            </div>

            <!-- Item -->
            <div class="swiper-slide h-auto py-3">
                <div class="card card-hover h-100 mx-2">
                    <div class="card-body">
                        <div class="d-table position-relative p-3 mb-4">
                            <img src="assets/img/landing/online-courses/icons/02.svg" class="position-relative zindex-2" width="32" alt="Icon">
                            <span class="bg-primary position-absolute top-0 start-0 w-100 h-100 rounded-circle opacity-8"></span>
                        </div>
                        <h3 class="h5 pb-1 mb-2">Comprehensive database:</h3>
                        <p class="mb-0">We have a comprehensive database of courses from top universities,
                            colleges, and vocational schools, so you can explore a wide range of options and
                            find the best fit for you.</p>
                    </div>
                </div>
            </div>

            <!-- Item -->
            <div class="swiper-slide h-auto py-3">
                <div class="card card-hover h-100 mx-2">
                    <div class="card-body">
                        <div class="d-table position-relative p-3 mb-4">
                            <img src="assets/img/landing/online-courses/icons/03.svg" class="position-relative zindex-2" width="32" alt="Icon">
                            <span class="bg-primary position-absolute top-0 start-0 w-100 h-100 rounded-circle opacity-8"></span>
                        </div>
                        <h3 class="h5 pb-1 mb-2">Simplified course search:</h3>
                        <p class="mb-0">We simplified the course search process by providing detailed
                            information about each course, including curriculum, duration, fees, and eligibility
                            criteria. This saves you time and effort in your search for the right course.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pagination (bullets) -->
        <div class="swiper-pagination position-relative pt-2 pt-sm-3 mt-4"></div>
    </div>
</section>
<!--why us section ends here-->

<!--FAQ Section is here-->
<section class="faq container pt-1 pt-lg-3">
    <div class="position-relative bg-primary rounded-3 overflow-hidden px-3 px-sm-4 px-md-0 py-5">

        <!-- Parallax patterns -->
        <div class="rellax position-absolute top-0 start-0 w-100 h-100 d-none d-lg-block" data-rellax-percentage="0.5" data-rellax-speed="1.75" style="transform: translate3d(-1px, 52px, 0px);">
            <img src="assets/img/landing/online-courses/pattern-1.svg" class="position-absolute top-0 start-100 translate-middle ms-n4" alt="Pattern">
            <img src="assets/img/landing/online-courses/pattern-2.svg" class="position-absolute top-50 start-0 mt-n5 ms-n5" alt="Pattern">
            <img src="assets/img/landing/online-courses/pattern-3.svg" class="position-absolute top-100 start-100 translate-middle ms-n5 mt-n5" alt="Pattern">
        </div>

        <div class="row justify-content-center position-relative zindex-2 py-lg-4">
            <div class="col-xl-8 col-lg-9 col-md-10 py-2">
                <h2 class="h1 text-light text-center mt-n2 mt-lg-0 mb-4 mb-lg-5">Frequently Asked Questions</h2>
                <div class="accordion" id="faq">

                    <!-- Item -->
                    <div class="accordion-item border-0 rounded-3 shadow-sm mb-3">
                        <h3 class="accordion-header">
                            <button class="accordion-button shadow-none rounded-3" type="button" data-bs-toggle="collapse" data-bs-target="#q-1" aria-expanded="true" aria-controls="q-1">What if I don't have any professional background?</button>
                        </h3>
                        <div class="accordion-collapse collapse show" id="q-1" data-bs-parent="#faq">
                            <div class="accordion-body fs-sm pt-0">
                                <p>Nunc duis id aenean gravida tincidunt eu, tempor ullamcorper. Viverra aliquam
                                    arcu, viverra et, cursus. Aliquet pretium cursus adipiscing gravida et
                                    consequat lobortis arcu velit. Nibh pharetra fermentum duis accumsan lectus
                                    non. Massa cursus molestie lorem scelerisque pellentesque. Nisi, enim, arcu
                                    purus gravida adipiscing euismod montes, duis egestas. Vehicula eu etiam
                                    quam tristique tincidunt suspendisse ut consequat.</p>
                                <p>Ornare senectus fusce dignissim ut. Integer consequat in eu tortor, faucibus
                                    et lacinia posuere. Turpis sit viverra lorem suspendisse lacus aliquam
                                    auctor vulputate. Quis egestas aliquam nunc purus lacus, elit leo elit
                                    facilisi. Dignissim amet adipiscing massa integer.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Item -->
                    <div class="accordion-item border-0 rounded-3 shadow-sm mb-3">
                        <h3 class="accordion-header">
                            <button class="accordion-button shadow-none rounded-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q-2" aria-expanded="false" aria-controls="q-2">How is this different from other courses on the
                                market?</button>
                        </h3>
                        <div class="accordion-collapse collapse" id="q-2" data-bs-parent="#faq">
                            <div class="accordion-body fs-sm pt-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce in facilisis
                                    nibh. Vestibulum ac porttitor sapien. Curabitur laoreet malesuada gravida.
                                    Phasellus vehicula vestibulum consequat. Curabitur feugiat eget sem vitae
                                    laoreet. Fusce porttitor finibus tellus, quis condimentum nibh. Vestibulum
                                    ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae;
                                    Vivamus vehicula malesuada magna at viverra. Fusce non est eget libero
                                    convallis fringilla suspendisse.</p>
                                <p>Nunc dolor velit, interdum finibus bibendum vel, mattis a magna. Mauris
                                    mollis sapien ac mi aliquet varius. Proin nec est nibh. Dignissim amet
                                    adipiscing massa integer.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Item -->
                    <div class="accordion-item border-0 rounded-3 shadow-sm mb-3">
                        <h3 class="accordion-header">
                            <button class="accordion-button shadow-none rounded-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q-3" aria-expanded="false" aria-controls="q-3">How much time does it take to do my homework per week? What
                                if I don't like it?</button>
                        </h3>
                        <div class="accordion-collapse collapse" id="q-3" data-bs-parent="#faq">
                            <div class="accordion-body fs-sm pt-0">
                                <p>Suspendisse viverra volutpat eros. Curabitur in scelerisque lacus, quis
                                    fringilla sem. Nunc rutrum vel magna et ullamcorper. Sed consectetur augue
                                    vitae ligula consectetur, eu dapibus justo molestie. Phasellus sit amet
                                    metus magna. Sed tincidunt tempus felis vitae commodo. Etiam lobortis justo
                                    in elit pretium, sit amet aliquet tellus euismod. Curabitur in purus sed
                                    turpis aliquet pretium. Nunc ut magna tempus, iaculis sem id, vulputate
                                    ipsum. Etiam fermentum malesuada quam, in tempus purus pulvinar at.
                                    Vestibulum auctor congue pharetra. Class aptent taciti sociosqu ad litora
                                    torquent per conubia nostra, per inceptos himenaeos. Nulla facilisi. Nunc
                                    dolor velit, interdum finibus bibendum vel, mattis a magna. Mauris mollis
                                    sapien ac mi aliquet varius. Proin nec est nibh. In hac habitasse platea
                                    dictumst. Nullam porta risus vitae lectus pellentesque interdum. Proin ac
                                    leo fermentum, volutpat odio ut, lacinia erat. Suspendisse potenti. Praesent
                                    vitae faucibus lectus. Sed tincidunt at ex id maximus. Morbi tristique
                                    ullamcorper velit, non cursus libero eleifend quis. Aliquam aliquam odio
                                    dui.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Item -->
                    <div class="accordion-item border-0 rounded-3 shadow-sm mb-3">
                        <h3 class="accordion-header">
                            <button class="accordion-button shadow-none rounded-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q-4" aria-expanded="false" aria-controls="q-4">Is there any kind of certificate of completion?</button>
                        </h3>
                        <div class="accordion-collapse collapse" id="q-4" data-bs-parent="#faq">
                            <div class="accordion-body fs-sm pt-0">
                                <p>Nunc duis id aenean gravida tincidunt eu, tempor ullamcorper. Viverra aliquam
                                    arcu, viverra et, cursus. Aliquet pretium cursus adipiscing gravida et
                                    consequat lobortis arcu velit. Nibh pharetra fermentum duis accumsan lectus
                                    non. Massa cursus molestie lorem scelerisque pellentesque. Nisi, enim, arcu
                                    purus gravida adipiscing euismod montes, duis egestas. Vehicula eu etiam
                                    quam tristique tincidunt suspendisse ut consequat.</p>
                                <p>Ornare senectus fusce dignissim ut. Integer consequat in eu tortor, faucibus
                                    et lacinia posuere. Turpis sit viverra lorem suspendisse lacus aliquam
                                    auctor vulputate. Quis egestas aliquam nunc purus lacus, elit leo elit
                                    facilisi. Dignissim amet adipiscing massa integer.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Item -->
                    <div class="accordion-item border-0 rounded-3 shadow-sm mb-3">
                        <h3 class="accordion-header">
                            <button class="accordion-button shadow-none rounded-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q-5" aria-expanded="false" aria-controls="q-5">YouTube is full of free tutorials, videos and courses. Why
                                should I take any courses here?</button>
                        </h3>
                        <div class="accordion-collapse collapse" id="q-5" data-bs-parent="#faq">
                            <div class="accordion-body fs-sm pt-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce in facilisis
                                    nibh. Vestibulum ac porttitor sapien. Curabitur laoreet malesuada gravida.
                                    Phasellus vehicula vestibulum consequat. Curabitur feugiat eget sem vitae
                                    laoreet. Fusce porttitor finibus tellus, quis condimentum nibh. Vestibulum
                                    ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae;
                                    Vivamus vehicula malesuada magna at viverra. Fusce non est eget libero
                                    convallis fringilla suspendisse.</p>
                                <p>Nunc dolor velit, interdum finibus bibendum vel, mattis a magna. Mauris
                                    mollis sapien ac mi aliquet varius. Proin nec est nibh. Dignissim amet
                                    adipiscing massa integer.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Item -->
                    <div class="accordion-item border-0 rounded-3 shadow-sm">
                        <h3 class="accordion-header">
                            <button class="accordion-button shadow-none rounded-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q-6" aria-expanded="false" aria-controls="q-6">What happens if I forget or lose my password?</button>
                        </h3>
                        <div class="accordion-collapse collapse" id="q-6" data-bs-parent="#faq">
                            <div class="accordion-body fs-sm pt-0">
                                <p>Suspendisse viverra volutpat eros. Curabitur in scelerisque lacus, quis
                                    fringilla sem. Nunc rutrum vel magna et ullamcorper. Sed consectetur augue
                                    vitae ligula consectetur, eu dapibus justo molestie. Phasellus sit amet
                                    metus magna. Sed tincidunt tempus felis vitae commodo. Etiam lobortis justo
                                    in elit pretium, sit amet aliquet tellus euismod. Curabitur in purus sed
                                    turpis aliquet pretium. Nunc ut magna tempus, iaculis sem id, vulputate
                                    ipsum. Etiam fermentum malesuada quam, in tempus purus pulvinar at.
                                    Vestibulum auctor congue pharetra. Class aptent taciti sociosqu ad litora
                                    torquent per conubia nostra, per inceptos himenaeos. Nulla facilisi. Nunc
                                    dolor velit, interdum finibus bibendum vel, mattis a magna. Mauris mollis
                                    sapien ac mi aliquet varius. Proin nec est nibh. In hac habitasse platea
                                    dictumst. Nullam porta risus vitae lectus pellentesque interdum. Proin ac
                                    leo fermentum, volutpat odio ut, lacinia erat. Suspendisse potenti. Praesent
                                    vitae faucibus lectus. Sed tincidunt at ex id maximus. Morbi tristique
                                    ullamcorper velit, non cursus libero eleifend quis. Aliquam aliquam odio
                                    dui.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--FAQ Section ends here-->

<!--news-->
<section class="bg-secondary border-bottom border-light py-5">
    <div class="container py-md-3 py-lg-5">
        <h2 class="h1 text-center pb-2">News &amp; Insights</h2>
        <div class="position-relative mx-md-2 px-md-5">

            <!-- Slider controls (Prev / next) -->
            <button type="button" id="news-prev" class="btn btn-prev btn-icon btn-sm position-absolute top-50 start-0 translate-middle-y mt-n4 d-none d-md-inline-flex" tabindex="0" aria-label="Previous slide" aria-controls="swiper-wrapper-4fc5c9b2f1016bc03">
                <i class="bx bx-chevron-left"></i>
            </button>
            <button type="button" id="news-next" class="btn btn-next btn-icon btn-sm position-absolute top-50 end-0 translate-middle-y mt-n4 d-none d-md-inline-flex" tabindex="0" aria-label="Next slide" aria-controls="swiper-wrapper-4fc5c9b2f1016bc03">
                <i class="bx bx-chevron-right"></i>
            </button>

            <!-- Swiper slider -->
            <div class="swiper swiper-nav-onhover mx-n2 swiper-initialized swiper-horizontal swiper-pointer-events" data-swiper-options="{
                  &quot;slidesPerView&quot;: 1,
                  &quot;loop&quot;: true,
                  &quot;spaceBetween&quot;: 8,
                  &quot;pagination&quot;: {
                    &quot;el&quot;: &quot;.swiper-pagination&quot;,
                    &quot;clickable&quot;: true
                  },
                  &quot;navigation&quot;: {
                    &quot;prevEl&quot;: &quot;#news-prev&quot;,
                    &quot;nextEl&quot;: &quot;#news-next&quot;
                  },
                  &quot;breakpoints&quot;: {
                    &quot;0&quot;: {
                      &quot;slidesPerView&quot;: 1
                    },
                    &quot;560&quot;: {
                      &quot;slidesPerView&quot;: 2
                    },
                    &quot;992&quot;: {
                      &quot;slidesPerView&quot;: 3
                    }
                  }
                }">
                <div class="swiper-wrapper" id="swiper-wrapper-4fc5c9b2f1016bc03" aria-live="polite" style="transition-duration: 0ms; transform: translate3d(-2818.67px, 0px, 0px);">
                    <div class="swiper-slide h-auto py-3 swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Software</a>
                                    <span class="fs-sm text-muted">May 24, 2021</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">What the Software Stock
                                        Slump Means for the Market</a>
                                </h3>
                                <p class="mb-0">Id mollis consectetur congue egestas egestas suspendisse blandit
                                    justo. Tellus augue commodo id quis tempus etiam pulvinar at maecenas.</p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">6</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">1</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">5</span>
                                </div>
                            </div>
                        </article>
                    </div>
                    <div class="swiper-slide h-auto py-3 swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="3" role="group" aria-label="4 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Startups</a>
                                    <span class="fs-sm text-muted">Sep 3, 2021</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">5 Bad Landing Page
                                        Examples &amp; How We Would Fix Them</a>
                                </h3>
                                <p class="mb-0">Totam, soluta placeat hic adipisci reprehenderit iusto est nulla
                                    dolorum doloremque inventore suscipit consequuntur distinctio id.</p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">8</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">7</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">3</span>
                                </div>
                            </div>
                        </article>
                    </div>
                    <div class="swiper-slide h-auto py-3 swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="4" role="group" aria-label="5 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Technology</a>
                                    <span class="fs-sm text-muted">Aug 19, 2021</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">Why UX Design Matters and
                                        How it Affects Ranking</a>
                                </h3>
                                <p class="mb-0">Quaerat quos assumenda numquam dolorem, repellendus est, itaque
                                    sint et odio perferendis laudantium laboriosam.</p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">5</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">3</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">9</span>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Item -->
                    <div class="swiper-slide h-auto py-3 swiper-slide-duplicate-next" data-swiper-slide-index="0" role="group" aria-label="1 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Tech</a>
                                    <span class="fs-sm text-muted">1 day ago</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">How the Millennial
                                        Lifestyle Changes as Service Prices Rise</a>
                                </h3>
                                <p class="mb-0">Sit facilisis dolor arcu, fermentum vestibulum arcu elementum
                                    imperdiet. Mauris duis eleifend faucibus amet sagittis.</p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">2</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">0</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">3</span>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Item -->
                    <div class="swiper-slide h-auto py-3" data-swiper-slide-index="1" role="group" aria-label="2 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Strategy</a>
                                    <span class="fs-sm text-muted">12 hours ago</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">Mobile App Generates Data
                                        for the Energy Management</a>
                                </h3>
                                <p class="mb-0">Sociis sit risus id. Sit facilisis dolor arcu, fermentum
                                    vestibulum arcu ele. Pulvinar at maecenas maecenas pharetra, tincidunt
                                    sollicitudin in in. </p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">8</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">4</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">2</span>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Item -->
                    <div class="swiper-slide h-auto py-3" data-swiper-slide-index="2" role="group" aria-label="3 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Software</a>
                                    <span class="fs-sm text-muted">May 24, 2021</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">What the Software Stock
                                        Slump Means for the Market</a>
                                </h3>
                                <p class="mb-0">Id mollis consectetur congue egestas egestas suspendisse blandit
                                    justo. Tellus augue commodo id quis tempus etiam pulvinar at maecenas.</p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">6</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">1</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">5</span>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Item -->
                    <div class="swiper-slide h-auto py-3 swiper-slide-prev" data-swiper-slide-index="3" role="group" aria-label="4 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Startups</a>
                                    <span class="fs-sm text-muted">Sep 3, 2021</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">5 Bad Landing Page
                                        Examples &amp; How We Would Fix Them</a>
                                </h3>
                                <p class="mb-0">Totam, soluta placeat hic adipisci reprehenderit iusto est nulla
                                    dolorum doloremque inventore suscipit consequuntur distinctio id.</p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">8</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">7</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">3</span>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Item -->
                    <div class="swiper-slide h-auto py-3 swiper-slide-active" data-swiper-slide-index="4" role="group" aria-label="5 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Technology</a>
                                    <span class="fs-sm text-muted">Aug 19, 2021</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">Why UX Design Matters and
                                        How it Affects Ranking</a>
                                </h3>
                                <p class="mb-0">Quaerat quos assumenda numquam dolorem, repellendus est, itaque
                                    sint et odio perferendis laudantium laboriosam.</p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">5</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">3</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">9</span>
                                </div>
                            </div>
                        </article>
                    </div>
                    <div class="swiper-slide h-auto py-3 swiper-slide-duplicate swiper-slide-next" data-swiper-slide-index="0" role="group" aria-label="1 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Tech</a>
                                    <span class="fs-sm text-muted">1 day ago</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">How the Millennial
                                        Lifestyle Changes as Service Prices Rise</a>
                                </h3>
                                <p class="mb-0">Sit facilisis dolor arcu, fermentum vestibulum arcu elementum
                                    imperdiet. Mauris duis eleifend faucibus amet sagittis.</p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">2</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">0</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">3</span>
                                </div>
                            </div>
                        </article>
                    </div>
                    <div class="swiper-slide h-auto py-3 swiper-slide-duplicate" data-swiper-slide-index="1" role="group" aria-label="2 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Strategy</a>
                                    <span class="fs-sm text-muted">12 hours ago</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">Mobile App Generates Data
                                        for the Energy Management</a>
                                </h3>
                                <p class="mb-0">Sociis sit risus id. Sit facilisis dolor arcu, fermentum
                                    vestibulum arcu ele. Pulvinar at maecenas maecenas pharetra, tincidunt
                                    sollicitudin in in. </p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">8</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">4</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">2</span>
                                </div>
                            </div>
                        </article>
                    </div>
                    <div class="swiper-slide h-auto py-3 swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 5" style="width: 394.667px; margin-right: 8px;">
                        <article class="card p-md-3 p-2 border-0 shadow-sm card-hover-primary h-100 mx-2">
                            <div class="card-body pb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <a href="#" class="badge fs-sm text-nav bg-secondary text-decoration-none position-relative zindex-2">Software</a>
                                    <span class="fs-sm text-muted">May 24, 2021</span>
                                </div>
                                <h3 class="h4">
                                    <a href="blog-single.php" class="stretched-link">What the Software Stock
                                        Slump Means for the Market</a>
                                </h3>
                                <p class="mb-0">Id mollis consectetur congue egestas egestas suspendisse blandit
                                    justo. Tellus augue commodo id quis tempus etiam pulvinar at maecenas.</p>
                            </div>
                            <div class="card-footer d-flex align-items-center py-4 text-muted border-top-0">
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-like fs-lg me-1"></i>
                                    <span class="fs-sm">6</span>
                                </div>
                                <div class="d-flex align-items-center me-3">
                                    <i class="bx bx-comment fs-lg me-1"></i>
                                    <span class="fs-sm">1</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-share-alt fs-lg me-1"></i>
                                    <span class="fs-sm">5</span>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>

                <!-- Pagination (bullets) -->
                <div class="swiper-pagination position-relative pt-2 pt-sm-3 mt-4 swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal">
                    <span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 1"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 2"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 3"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 4"></span><span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button" aria-label="Go to slide 5" aria-current="true"></span>
                </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
            </div>
        </div>
    </div>
</section>
<!--news ends-->
<?php
include("includes/footer.php");
?>