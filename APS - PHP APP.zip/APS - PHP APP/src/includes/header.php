<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Career Discover | Online APS Calculator and Course Discovery</title>
    <!--SEO TAGS HERE-->
    <!--SEO TAGS ENDS HERE-->

    <!-- Viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon and Touch Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/favicon/site.webmanifest">
    <link rel="mask-icon" href="assets/favicon/safari-pinned-tab.svg" color="#6366f1">
    <link rel="shortcut icon" href="assets/favicon/favicon.ico">
    <meta name="msapplication-TileColor" content="#080032">
    <meta name="msapplication-config" content="assets/favicon/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">

    <!--font awesome icons-->
    <link rel="icon" media="screen" href="assets\icons\css\all.css">


    <!-- Vendor Styles -->
    <link rel="stylesheet" media="screen" href="assets/vendor/boxicons/css/boxicons.min.css" />
    <link rel="stylesheet" media="screen" href="assets/vendor/swiper/swiper-bundle.min.css" />

    <!-- Main Theme Styles + Bootstrap -->
    <link rel="stylesheet" media="screen" href="assets/css/theme.min.css">

    <!--Website Style-->
    <link rel="stylesheet" media="screen" href="assets\css\style.css">

    <!-- Theme mode -->
    <script>
        let mode = window.localStorage.getItem('mode'),
            root = document.getElementsByTagName('html')[0];
        if (mode !== null && mode === 'dark') {
            root.classList.add('dark-mode');
        } else {
            root.classList.remove('dark-mode');
        }
    </script>

    <!-- Page loading scripts -->
    <script>
        (function() {
            window.onload = function() {
                const preloader = document.querySelector('.page-loading');
                preloader.classList.remove('active');
                setTimeout(function() {
                    preloader.remove();
                }, 1000);
            };
        })();
    </script>
    <style>
        .top-bar {
            background-color: #ffc107;
            /* Yellow background color, you can change it to fit your design */
            color: #333;
            /* Text color, you can adjust it based on your design */
            padding: 10px;
            text-align: center;
            font-size: 14px;
            /* Adjust the font size as needed */
            font-weight: bold;
        }

        /* Additional styles for better visibility */
        .top-bar p {
            margin: 0;
        }
    </style>
</head>

<body>

    <!-- Page loading spinner -->
    <div class="page-loading active">
        <div class="page-loading-inner">
            <div class="page-spinner"></div><span>Loading...</span>
        </div>
    </div>

    <main class="page-wrapper">
        <!-- Navbar -->
        <div class="top-bar">
            <p>This app is still in beta. Some functions may not be fully operational yet. and has dummy content</p>
        </div>
        <!-- Remove "navbar-sticky" class to make navigation bar scrollable with the page -->
        <header class="navbar navbar-expand-lg bg-light shadow-sm navbar-sticky">
            <div class="container">
                <a href="#" class="navbar-brand">
                    Career Discovery
                </a>
                <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse2" aria-expanded="false">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="form-check form-switch mode-switch order-lg-2 ms-4 ms-lg-auto me-lg-4" data-bs-toggle="mode">
                    <input type="checkbox" class="form-check-input" id="theme-mode">
                    <label class="form-check-label d-none d-sm-block d-lg-none d-xl-block" for="theme-mode">Light</label>
                    <label class="form-check-label d-none d-sm-block d-lg-none d-xl-block" for="theme-mode">Dark</label>
                </div>
                <!-- <a href="pages\signin.php"
                    class="btn btn-secondary btn-sm fs-sm rounded order-lg-3 d-none d-lg-inline-flex">
                    <i class="bx bx-log-in fs-lg me-2"></i>
                    Sign in
                </a> -->
                <nav id="navbarCollapse2" class="collapse navbar-collapse">
                    <hr class="d-lg-none mt-3 mb-2">
                    <ul class="navbar-nav me-auto">
                        <!-- <li class="nav-item">
                            <a href="pages\About-us.php" class="nav-link active">About Us</a>
                        </li> -->
                        <li class="nav-item">
                            <a href="courses.php" class="nav-link">Courses</a>
                        </li>
                        <!-- <li class="nav-item">
                            <a href="pages\Resources.php" class="nav-link">Resources</a>
                        </li>
                        <li class="nav-item">
                            <a href="pages\university.php" class="nav-link">Universities</a>
                        </li> -->

                    </ul>
                    <!-- <a href="pages\signin.php" class="btn btn-secondary btn-sm fs-sm rounded my-3 d-lg-none">
                        <i class="bx bx-log-in fs-lg me-2"></i>
                        Sign in
                    </a> -->
                </nav>
            </div>
        </header>