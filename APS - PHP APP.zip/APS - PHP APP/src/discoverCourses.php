<?php

session_start();
include("includes/header.php");
include("includes/database.php");

$apsScore1 = $_GET['apsScore'];
$mathsOptionScore1 = $_GET['mathsOptionScore'];
$homeLanguageScore1 = $_GET['homeLanguageScore'];

$apsScore = $apsScore1;
$mathsOptionScore = $mathsOptionScore1;
$homeLanguageScore = $homeLanguageScore1;

// Define the number of courses per page
$perPage = 9;

// Get the current page number from the URL, default to 1
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;

// Calculate the offset for the SQL query
$offset = ($page - 1) * $perPage;

if ($_GET['homeLanguageScore'] >= 50 && $_GET['mathsOption'] === "Maths") {
    $maths_query = "SELECT course.qualificationName, course.qualification, course.duration, course.qualificationDescription, course.link, course.withMathsScore, course.withMathsLitScore, course.minMaths, course.minMathsLit, qualificationType.qualificationTypeName, university.universityAbriviationName, faculty.facultyName
    FROM `course`
    INNER JOIN university ON course.universityID = university.universityID 
    INNER JOIN qualificationType ON course.qualificationTypeID = qualificationType.qualificationTypeID 
    INNER JOIN faculty ON course.facultyID = faculty.facultyID 
    WHERE withMathsScore <= $apsScore AND minMaths <= $mathsOptionScore AND $homeLanguageScore >= 50
    LIMIT $offset, $perPage;";
    $maths_results = mysqli_query($conn, $maths_query);

    if (!$maths_results) {
        // Query execution failed, handle the error
        die("Query failed: " . mysqli_error($conn));
    }

?>
<style>
#main_pagination {
    width: 100% !important;
}
</style>
<section class="container mt-5 mb-md-2 mb-lg-4 mb-xl-5">
    <nav class="pt-4 mt-lg-3" aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item">
                <a href="landing-online-courses.html"><i class="bx bx-home-alt fs-lg me-1"></i>Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Courses</li>
        </ol>
    </nav>

    <div class="d-lg-flex align-items-center justify-content-between py-4 mt-lg-2">
        <h1 class="me-3">Courses</h1>
        <div class="d-md-flex mb-3">
            <select class="form-select me-md-4 mb-2 mb-md-0" style="min-width: 240px;">
                <option value="All">All categories</option>
                <option value="Web Development">Web Development</option>
                <option value="Mobile Development">Mobile Development</option>
                <option value="Programming">Programming</option>
                <option value="Game Development">Game Development</option>
                <option value="Software Testing">Software Testing</option>
                <option value="Software Engineering">Software Engineering</option>
                <option value="Network &amp; Security">Network &amp; Security</option>
            </select>
            <select class="form-select me-md-4 mb-2 mb-md-0" style="min-width: 240px;">
                <option value="All">All Faculties</option>
                <option value="Web Development">Web Development</option>
                <option value="Mobile Development">Mobile Development</option>
                <option value="Programming">Programming</option>
                <option value="Game Development">Game Development</option>
                <option value="Software Testing">Software Testing</option>
                <option value="Software Engineering">Software Engineering</option>
                <option value="Network &amp; Security">Network &amp; Security</option>
            </select>
            <div class="position-relative" style="min-width: 300px;">
                <input type="text" class="form-control pe-5" placeholder="Search courses">
                <i class="bx bx-search text-nav fs-lg position-absolute top-50 end-0 translate-middle-y me-3"></i>
            </div>
        </div>
    </div>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 gx-3 gx-md-4 mt-n2 mt-sm-0">

        <?php
            while ($data = mysqli_fetch_array($maths_results)) {

            ?>
        <div class="col pb-1 pb-lg-3 mb-4">
            <article class="card h-100 card-hover border-0 shadow-sm">
                <div class="card-body pb-4">
                    <h5 class="h5 mb-0">
                        <a href="#"><?php echo $data['qualificationName']; ?></a>
                    </h5>
                    <p class="subHeading muted mb-4"><?php echo $data['qualification']; ?></p>
                    <p id="qual_description">
                        <?php
                                $qualificationDescription = $data['qualificationDescription'];

                                // Check if the length is more than 120 characters
                                if (strlen($qualificationDescription) > 120) {
                                    // Trim the text to 120 characters and append "..."
                                    $truncatedText = substr($qualificationDescription, 0, 120) . '...';
                                } else {
                                    // If the length is 120 characters or less, keep the original text
                                    $truncatedText = $qualificationDescription;
                                }
                                ?>
                        <?php echo $truncatedText; ?>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-borderless" style="padding: 0; margin: 0;">
                            <tbody class="tableStyling">
                                <tr style="border-style: none;">
                                    <td class="px-0">
                                        <p class="fs-sm mb-2"> Offerd:
                                            <span class="h6">
                                                <a href="#"><?php echo $data['universityAbriviationName']; ?></a>
                                            </span>
                                        </p>
                                    </td>
                                    <td class="px-0">
                                        <p class="fs-sm mb-2">
                                            Score:
                                            <span class="h6"><?php echo $data['withMathsScore']; ?></span>
                                        </p>
                                    </td>
                                    <td class="px-0">
                                        <p class="fs-sm mb-2">
                                            Duration:
                                            <span class="h6"><?php echo $data['duration']; ?> Year</span>
                                        </p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center fs-sm text-muted py-4">
                    <div class="d-flex align-items-center me-4">
                        <a href="#" class="btn btn-sm btn-primary" style="margin-right: 5px;">Go somewhere</a>
                        <a href="#" class="btn btn-sm btn-primary">Go somewhere</a>
                    </div>
                </div>
            </article>
        </div>
        <?php
            }
            ?>
        <!-- Pagination Links -->
        <!-- Pagination Links -->
        <nav aria-label="Page navigation example" class="nav justify-content-center" id="main_pagination">
            <ul class="pagination">
                <?php
                    // Calculate the total number of pages
                    $maths_query = "SELECT COUNT(*) as totalCourses
                    FROM `course`
                    INNER JOIN university ON course.universityID = university.universityID 
                    INNER JOIN qualificationType ON course.qualificationTypeID = qualificationType.qualificationTypeID 
                    INNER JOIN faculty ON course.facultyID = faculty.facultyID 
                    WHERE withMathsScore <= $apsScore AND minMaths <= $mathsOptionScore AND $homeLanguageScore >= 50";

                    // Execute the query
                    $result = mysqli_query($conn, $maths_query);

                    // Check if the query executed successfully
                    if ($result) {
                        // Fetch the result as an associative array
                        $row = mysqli_fetch_assoc($result);

                        // Store the total number of courses in $totalCourses
                        $totalCourses = $row['totalCourses'];
                    } else {
                        // Query execution failed, handle the error
                        die("Query failed: " . mysqli_error($conn));
                    }

                    $totalPages = ceil($totalCourses / $perPage);

                    // Generate pagination links
                    for ($i = 1; $i <= $totalPages; $i++) {
                        // Include existing parameters and add the page parameter
                        $queryParams = http_build_query(array_merge($_GET, ['page' => $i]));
                        echo '<li class="page-item ' . ($i === $page ? 'active' : '') . '"><a class="page-link" href="?' . $queryParams . '">' . $i . '</a></li>';
                    }
                    ?>

            </ul>
        </nav>

</section>
<?php
} elseif ($_GET['homeLanguageScore'] >= 50 && $_GET['mathsOption'] === "MathsLit") {
    $maths_query = "SELECT * FROM `course` WHERE withMathsLitScore <= $apsScore AND minMathsLit <= $mathsOptionScore AND $homeLanguageScore >= 50;";
    $maths_results = mysqli_query($conn, $maths_query);

    if (!$maths_results) {
        // Query execution failed, handle the error
        die("Query failed: " . mysqli_error($conn));
    }
    while ($data = mysqli_fetch_array($maths_results)) {
        // Your code to display data
        echo '<h1>' . $data['qualificationName'] . '</h1>';
    }
} else {
    if ($_GET['homeLanguageScore'] < 50) {
        echo "You do not qualify, because your home language is less than 50%, try again next year!";
    }

    //this condition needs to be dynamic and not hard coded
    else if ($_GET['apsScore'] < 280) {
        echo "You do not qualify, because your aps score is less than 280, try again next year!";
    } else if ($_GET['mathsOptionScore'] < 30) {
        echo "You do not qualify, because your maths score is less than 30%, try again next year!";
    }
}
?>

<?php
include("includes/footer.php");
?>