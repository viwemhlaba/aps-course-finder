
var apsTotalScoreCalculated = 0;

function calculate(event) {
    event.preventDefault();

    const homeLanguage = document.getElementById("homeLanguage").value;
    const homeLanguageScore = document.getElementById("homeLanguageScore").value;
    const firstAdditionalLanguage = document.getElementById("firstAdditionalLanguage").value;
    const firstAdditionalLanguageScore = document.getElementById("firstAdditionalLanguageScore").value;
    const mathsOption = document.getElementById("mathsOption").value;
    const mathsOptionScore = document.getElementById("mathsOptionScore").value;
    const subjectfour = document.getElementById("subjectfour").value;
    const subjectfourScore = document.getElementById("subjectfourScore").value;
    const subjectfive = document.getElementById("subjectfive").value;
    const subjectfiveScore = document.getElementById("subjectfiveScore").value;
    const subjectsix = document.getElementById("subjectsix").value;
    const subjectsixScore = document.getElementById("subjectsixScore").value;

    //calculates the AS Score
    let apsTotalScoreCalculated = Number(homeLanguageScore) + Number(firstAdditionalLanguageScore) + Number(mathsOptionScore) + Number(subjectfourScore) + Number(subjectfiveScore) + Number(subjectsixScore);

    //process the actual thing
    if (apsTotalScoreCalculated >= 290) {
        if (homeLanguageScore >= 50) {
            if ((mathsOption === "Maths" && mathsOptionScore >= 35) || (mathsOption === "Mathslit" && mathsOptionScore >= 50)) {
                document.getElementById("apsScore").innerHTML = apsTotalScoreCalculated;
                document.getElementById("messagescore").innerHTML = "Great News you do qualify for a number of courses, Please use our system to go through all the course that your qualify for.";
            } else {
                document.getElementById("apsScore").innerHTML = apsTotalScoreCalculated;
                document.getElementById("messagescore").innerHTML = "Unfortunately due to your Maths score is Low";
            }
        } else {
            document.getElementById("apsScore").innerHTML = apsTotalScoreCalculated;
            document.getElementById("messagescore").innerHTML = "Unfortunately due to your language score is Low";
        }
    } else {
        document.getElementById("apsScore").innerHTML = apsTotalScoreCalculated;
        document.getElementById("messagescore").innerHTML = "Unfortunately due to your Applicant Score you do not meet the minimum requirement for admission. However it is not the end of the road, see what other alternatives are available for you";
    }

    //hide the form and show the success message
    const form = document.getElementById('calculatejspage');
    form.style.display = 'none';
    const successDiv = document.getElementById('successform');
    successDiv.style.display = 'block';
}

document.getElementById('calculatebtnaps').addEventListener('click', calculate);
