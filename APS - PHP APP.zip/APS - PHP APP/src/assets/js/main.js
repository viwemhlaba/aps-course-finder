document.addEventListener('DOMContentLoaded', function () {
    var qualificationDescriptionElement = document.getElementById('qual_description');
    var qualificationDescription = qualificationDescriptionElement.textContent.trim();

    // Check if the length is more than 120 characters
    if (qualificationDescription.length > 120) {
        // Trim the text to 120 characters and append "..."
        var truncatedText = qualificationDescription.substring(0, 120) + '...';
        qualificationDescriptionElement.textContent = truncatedText;
    }
});