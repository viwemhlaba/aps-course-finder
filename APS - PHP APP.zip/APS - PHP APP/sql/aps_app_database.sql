-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 30, 2021 at 09:02 AM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aps_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `facultyID` int NOT NULL,
  `universityID` int NOT NULL,
  `facultyName` varchar(100) NOT NULL
) ENGINE=InnoDB;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`facultyID`, `universityID`, `facultyName`) VALUES
(1, 1, 'School of Business & Economic Science');

-- --------------------------------------------------------

--
-- Table structure for table `qualificationCategory`
--

CREATE TABLE `qualificationCategory` (
  `qualificationCategoryID` int NOT NULL,
  `qualificationTypeID` int NOT NULL,
  `qualificationCategoryName` varchar(100) NOT NULL
) ENGINE=InnoDB;

--
-- Dumping data for table `qualificationCategory`
--

INSERT INTO `qualificationCategory` (`qualificationCategoryID`, `qualificationTypeID`, `qualificationCategoryName`) VALUES
(1, 1, 'Higher Certificate'),
(2, 1, 'Diploma'),
(3, 1, 'Advanced Diploma'),
(4, 1, 'Bachelors Degree'),
(5, 2, 'Post Graduate Diploma'),
(6, 2, 'Honours Degree'),
(7, 2, 'Masters Degree'),
(8, 2, 'Doctoral Degree');

-- --------------------------------------------------------

--
-- Table structure for table `qualificationType`
--

CREATE TABLE `qualificationType` (
  `qualificationTypeID` int NOT NULL,
  `qualificationTypeName` varchar(100) NOT NULL
) ENGINE=InnoDB;

--
-- Dumping data for table `qualificationType`
--

INSERT INTO `qualificationType` (`qualificationTypeID`, `qualificationTypeName`) VALUES
(1, 'Undergraduate'),
(2, 'Post-Graduate');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
    `courseId` INT NOT NULL,
    `universityID` INT NOT NULL,
    `qualificationTypeID` INT NOT NULL,
    `qualificationCategoryID` INT NOT NULL,
    `facultyID` INT NOT NULL,
    `qualification` varchar(100) NOT NULL,
    `qualificationName` varchar(100) NOT NULL,
    `duration` varchar(100) NOT NULL,
    `withMathsScore` varchar(100) NOT NULL,
    `withMathsLitScore` varchar(100) NOT NULL,
    `minMaths` varchar(100) NOT NULL,
    `minMathsLit` varchar(100) NOT NULL
) ENGINE=InnoDB;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`courseId`, `universityID`,`qualificationTypeID`,`qualificationCategoryID`, `facultyID`,`qualification`,`qualificationName`,`duration`,`withMathsScore`, `withMathsLitScore`,`minMaths`,`minMathsLit`) VALUES 
  (1,1,1,1,1,'Higher Certificate (Hcert)','Accountancy',1,290,305,35,60),
	(2,1,1,1,1,'Higher Certificate (Hcert)','Business Studies',1,290,305,30,50),
	(3,1,1,2,1,'Diploma (Dip)','Accountancy',3,350,365,45,65),
	(4,1,1,2,1,'Diploma (Dip)','Economics',3,330,345,40,60),
	(5,1,1,2,1,'Diploma (Dip)','Economics (Extended)',4,310,325,35,55),
	(6,1,1,2,1,'Diploma (Dip)','Human Resources Management',3,330,345,35,55),
	(7,1,1,2,1,'Diploma (Dip)','Human Resources Management (Extended)',4,310,325,30,50),
	(8,1,1,2,1,'Diploma (Dip)','Inventory Stores Management',3,290,305,30,50),
	(9,1,1,2,1,'Diploma (Dip)','Logistics',3,330,345,40,60),
	(10,1,1,2,1,'Diploma (Dip)','Logistics (Extended)',4,310,325,35,55),
	(11,1,1,2,1,'Diploma (Dip)','Management',3,310,325,35,55),
	(12,1,1,2,1,'Diploma (Dip)','Management (Extended)',4,330,345,40,60),
	(13,1,1,2,1,'Diploma (Dip)','Marketing',3,330,345,40,60),
	(14,1,1,2,1,'Diploma (Dip)','Marketing (Extended)',4,310,325,35,55),
	(15,1,1,2,1,'Diploma (Dip)','Tourism Management',3,330,345,40,60),
	(16,1,1,2,1,'Diploma (Dip)','Tourism Management (Extended)',4,310,325,35,55),
	(17,1,1,4,1,'Bachelor of Commerce (BCom)','General (Economics)',3,390,0,50,0),
	(18,1,1,4,1,'Bachelor of Commerce (BCom)','General (Economics - Extended)',4,370,0,45,0),
	(19,1,1,4,1,'Bachelor of Commerce (BCom)','General (Accounting & Related Subjects)',3,390,0,50,0),
	(20,1,1,4,1,'Bachelor of Commerce (BCom)','General (Accounting - Extended)',4,370,0,45,0),
	(21,1,1,4,1,'Bachelor of Commerce (BCom)','General (Business Management)',3,390,0,50,0),
	(22,1,1,4,1,'Bachelor of Commerce (BCom)','General (Business Management - Extended)',4,370,0,45,0),
	(23,1,1,4,1,'Bachelor of Commerce (BCom)','Financial Planning',3,390,0,50,0),
	(24,1,1,4,1,'Bachelor of Commerce (BCom)','Financial Planning (Extended)',4,370,0,45,0),
	(25,1,1,4,1,'Bachelor of Commerce (BCom)','General (Tourism)',3,390,405,50,70),
	(26,1,1,4,1,'Bachelor of Commerce (BCom)','General (Tourism - Extended)',4,370,385,45,65),
	(27,1,1,4,1,'Bachelor of Commerce (BCom)','Marketing & Business Management',3,390,0,50,0),
	(28,1,1,4,1,'Bachelor of Commerce (BCom)','Hospitality Management',3,390,405,50,70),
	(29,1,1,4,1,'Bachelor of Commerce (BCom)','General (Statistics)',3,390,0,60,0),
	(30,1,1,4,1,'Bachelor of Commerce (BCom)','Accounting',3,410,0,60,0),
	(31,1,1,4,1,'Bachelor of Commerce (BCom)','Computer Science & Information Systems',3,390,0,60,0),
	(32,1,1,4,1,'Bachelor of Commerce (BCom)','Economics & Statistics',3,390,0,60,0),
	(33,1,1,4,1,'Bachelor of Commerce (BCom)','Industrial Pyschology & Human Resource Management',3,390,0,50,0),
	(34,1,1,4,1,'Bachelor of Commerce (BCom)','Information Systems (Business Management)',3,390,0,60,0),
	(35,1,1,4,1,'Bachelor of Commerce (BCom)','Logistics & Transport Economics',3,390,0,50,0),
	(36,1,1,4,1,'Bachelor of Commerce (BCom)','Food Service Management',3,390,0,50,0),
	(37,1,1,4,1,'Bachelor of Commerce (BCom)','Accounting Science (Economics / Business Management)',4,410,0,65,0),
	(38,1,1,4,1,'Bachelor of Commerce (BCom)','Accounting Science (Law)',4,410,0,65,0),
	(39,1,1,4,1,'Bachelor of Commerce (BCom)','Accounting Science (Computer Science & Information Systems)',4,410,0,65,0),
	(40,1,1,4,1,'Bachelor of Arts (BA)','Human Resource Management',3,350,365,40,70),
	(41,1,1,4,1,'Bachelor of Arts (BA)','Development Studies',3,350,365,40,70);


-- --------------------------------------------------------

--
-- Table structure for table `university`
--

CREATE TABLE `university` (
  `universityID` int NOT NULL,
  `universityName` varchar(100) NOT NULL
) ENGINE=InnoDB;

--
-- Dumping data for table `university`
--

INSERT INTO `university` (`universityID`, `universityName`) VALUES
(1, 'Nelson Mandela University');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`facultyID`),
  ADD KEY `fk_universityID` (`universityID`);


--
-- Indexes for table `course`
--

ALTER TABLE `course`
  ADD PRIMARY KEY (`courseId`),
  ADD KEY `fkc_universityID` (`universityID`),
  ADD KEY `fkc_qualificationTypeID` (`qualificationTypeID`),
  ADD KEY `fkc_qualificationCategoryID` (`qualificationCategoryID`),
  ADD KEY `fkc_facultyID` (`facultyID`);
  

--
-- Indexes for table `qualificationCategory`
--
ALTER TABLE `qualificationCategory`
  ADD PRIMARY KEY (`qualificationCategoryID`),
  ADD KEY `fk_qualificationTypeID` (`qualificationTypeID`);

--
-- Indexes for table `qualificationType`
--
ALTER TABLE `qualificationType`
  ADD PRIMARY KEY (`qualificationTypeID`);

--
-- Indexes for table `university`
--
ALTER TABLE `university`
  ADD PRIMARY KEY (`universityID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `facultyID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course`
--

ALTER TABLE `course`
  MODIFY `courseId` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `qualificationCategory`
--
ALTER TABLE `qualificationCategory`
  MODIFY `qualificationCategoryID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `qualificationType`
--
ALTER TABLE `qualificationType`
  MODIFY `qualificationTypeID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `university`
--
ALTER TABLE `university`
  MODIFY `universityID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `fk_universityID` FOREIGN KEY (`universityID`) REFERENCES `university` (`universityID`) ON DELETE RESTRICT ON UPDATE RESTRICT;


--
-- Constraints for table `faculty`
--

ALTER TABLE `course`
  ADD CONSTRAINT `fkc_qualificationTypeID` FOREIGN KEY (`qualificationTypeID`) REFERENCES `qualificationType` (`qualificationTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fkc_universityID` FOREIGN KEY (`universityID`) REFERENCES `university` (`universityID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fkc_qualificationCategoryID` FOREIGN KEY (`qualificationCategoryID`) REFERENCES `qualificationCategory` (`qualificationCategoryID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fkc_facultyID` FOREIGN KEY (`facultyID`) REFERENCES `faculty` (`facultyID`) ON DELETE RESTRICT ON UPDATE RESTRICT;
--
-- Constraints for table `qualificationCategory`
--
ALTER TABLE `qualificationCategory`
  ADD CONSTRAINT `fk_qualificationTypeID` FOREIGN KEY (`qualificationTypeID`) REFERENCES `qualificationType` (`qualificationTypeID`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
